
local UIPageViewItem = class("UIPageViewItem", function()
	return display.newNode()
end)

function UIPageViewItem:ctor()
end

return UIPageViewItem
