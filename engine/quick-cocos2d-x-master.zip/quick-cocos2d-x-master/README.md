新版在 [https://github.com/dualface/quick2d-engine](https://github.com/dualface/quick2d-engine)

