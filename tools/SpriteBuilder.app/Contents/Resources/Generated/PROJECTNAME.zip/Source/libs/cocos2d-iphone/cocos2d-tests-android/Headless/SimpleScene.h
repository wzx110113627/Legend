//
//  SimpleScene.h
//  cocos2d-tests-ios
//
//  Created by Oleg Osin on 6/3/14.
//  Copyright (c) 2014 Cocos2d. All rights reserved.
//

#import "TestBase.h"

@interface SimpleScene : TestBase

@end
