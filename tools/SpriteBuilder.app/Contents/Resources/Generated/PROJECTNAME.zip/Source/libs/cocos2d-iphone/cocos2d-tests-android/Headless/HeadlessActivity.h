//
//  HeadlessActivity.h
//  Headless
//
//  Created by Philippe Hausler on 7/8/14.
//  Copyright (c) 2014 Apportable. All rights reserved.
//

#import "CCActivity.h"

BRIDGE_CLASS("org.cocos2d.demo.HeadlessActivity")
@interface HeadlessActivity : CCActivity

@end
