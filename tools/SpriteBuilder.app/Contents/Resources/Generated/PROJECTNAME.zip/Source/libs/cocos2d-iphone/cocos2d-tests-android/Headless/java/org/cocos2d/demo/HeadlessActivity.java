package org.cocos2d.demo;

import org.cocos2d.CCActivity;

public class HeadlessActivity extends CCActivity {

}